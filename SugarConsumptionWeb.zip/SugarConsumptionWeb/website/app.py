from flask import Flask, render_template, request, redirect
import sqlite3
import plotly.graph_objs as go
import pandas as pd

app = Flask(__name__)

def get_df():
    conn = sqlite3.connect("../sugar_data.db")
    df = pd.read_sql("SELECT * FROM sugar_consumption", conn)
    conn.close()
    return df

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/data")
def data():
    df = get_df().head(100)
    return render_template("data.html", columns=df.columns, rows=df.values.tolist())

@app.route("/filter", methods=["GET", "POST"])
def filter():
    df = get_df()
    results = None
    if request.method == "POST":
        country = request.form.get("country")
        year = request.form.get("year")
        if country:
            df = df[df["Country"].str.contains(country, case=False)]
        if year:
            df = df[df["Year"] == int(year)]
        results = df.values.tolist()
    return render_template("filter.html", columns=df.columns, rows=results)

@app.route("/charts")
def charts():
    df = get_df()
    avg_sugar = df.groupby("Year")["Per_Capita_Sugar_Consumption"].mean()
    chart = go.Figure([go.Scatter(x=avg_sugar.index, y=avg_sugar.values, mode='lines+markers')])
    chart.update_layout(title="Average Per Capita Sugar Consumption Over Time",
                        xaxis_title="Year", yaxis_title="Sugar Consumption (kg)")
    chart_html = chart.to_html(full_html=False)
    return render_template("charts.html", chart_html=chart_html)

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        data = [request.form.get(col) for col in request.form]
        cols = ",".join(request.form.keys())
        placeholders = ",".join(["?"] * len(data))
        conn = sqlite3.connect("../sugar_data.db")
        cursor = conn.cursor()
        cursor.execute(f"INSERT INTO sugar_consumption ({cols}) VALUES ({placeholders})", data)
        conn.commit()
        conn.close()
        return redirect("/data")
    columns = get_df().columns.tolist()
    return render_template("add.html", columns=columns)

if __name__ == "__main__":
    app.run(debug=True)
