from data_collection.load_data import load_data

def preprocess_data():
    df = load_data()
    df = df.dropna(subset=["Gov_Tax", "Education_Campaign"])
    return df
