# Sugar Consumption Web App

This Flask-based web app lets you explore a dataset of global sugar consumption.

## Features

- View data
- Filter/search by country/year
- Visualize sugar consumption over time (Plotly)
- Add new records to database

## Setup

1. Install requirements:
```
pip install -r requirements.txt
```

2. Create the database:
```
cd database
python setup_db.py
```

3. Run the web app:
```
cd C:\Users\komal\Downloads\SugarConsumptionWeb\website
python app.py
```
