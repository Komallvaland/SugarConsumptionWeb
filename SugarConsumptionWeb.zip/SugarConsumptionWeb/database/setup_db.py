import sqlite3
from data_processing.process_data import preprocess_data

def create_db():
    conn = sqlite3.connect("sugar_data.db")
    df = preprocess_data()
    df.to_sql("sugar_consumption", conn, if_exists="replace", index=False)
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_db()
