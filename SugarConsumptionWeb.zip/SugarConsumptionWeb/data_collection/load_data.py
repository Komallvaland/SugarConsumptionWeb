import pandas as pd

def load_data(filepath="data_collection/sugar_consumption_dataset.csv"):
    df = pd.read_csv(filepath)
    return df
